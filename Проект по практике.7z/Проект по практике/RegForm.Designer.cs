﻿namespace Zad_VlaNa
{
    partial class RegForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Reg = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.tx1 = new System.Windows.Forms.TextBox();
            this.tx2 = new System.Windows.Forms.TextBox();
            this.tx3 = new System.Windows.Forms.TextBox();
            this.tx4 = new System.Windows.Forms.TextBox();
            this.tx5 = new System.Windows.Forms.TextBox();
            this.tx6 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tx7 = new System.Windows.Forms.TextBox();
            this.Prev = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Reg
            // 
            this.Reg.Location = new System.Drawing.Point(141, 224);
            this.Reg.Name = "Reg";
            this.Reg.Size = new System.Drawing.Size(114, 23);
            this.Reg.TabIndex = 0;
            this.Reg.Text = "Регистрация";
            this.Reg.UseVisualStyleBackColor = true;
            this.Reg.Click += new System.EventHandler(this.Reg_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(196, 274);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 23);
            this.Exit.TabIndex = 2;
            this.Exit.Text = "Выход";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // tx1
            // 
            this.tx1.Location = new System.Drawing.Point(141, 42);
            this.tx1.Name = "tx1";
            this.tx1.Size = new System.Drawing.Size(114, 20);
            this.tx1.TabIndex = 3;
            // 
            // tx2
            // 
            this.tx2.Location = new System.Drawing.Point(141, 68);
            this.tx2.Name = "tx2";
            this.tx2.Size = new System.Drawing.Size(114, 20);
            this.tx2.TabIndex = 4;
            // 
            // tx3
            // 
            this.tx3.Location = new System.Drawing.Point(141, 94);
            this.tx3.Name = "tx3";
            this.tx3.Size = new System.Drawing.Size(114, 20);
            this.tx3.TabIndex = 5;
            // 
            // tx4
            // 
            this.tx4.Location = new System.Drawing.Point(141, 120);
            this.tx4.Name = "tx4";
            this.tx4.Size = new System.Drawing.Size(114, 20);
            this.tx4.TabIndex = 6;
            // 
            // tx5
            // 
            this.tx5.Location = new System.Drawing.Point(141, 146);
            this.tx5.Name = "tx5";
            this.tx5.Size = new System.Drawing.Size(114, 20);
            this.tx5.TabIndex = 7;
            // 
            // tx6
            // 
            this.tx6.Location = new System.Drawing.Point(141, 172);
            this.tx6.Name = "tx6";
            this.tx6.Size = new System.Drawing.Size(114, 20);
            this.tx6.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Имя";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Фамилия";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Отчество";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(68, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Почта";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(69, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "логин";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(69, 175);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Пароль";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 201);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Повторите пароль";
            // 
            // tx7
            // 
            this.tx7.Location = new System.Drawing.Point(141, 198);
            this.tx7.Name = "tx7";
            this.tx7.Size = new System.Drawing.Size(114, 20);
            this.tx7.TabIndex = 15;
            // 
            // Prev
            // 
            this.Prev.Location = new System.Drawing.Point(17, 274);
            this.Prev.Name = "Prev";
            this.Prev.Size = new System.Drawing.Size(75, 23);
            this.Prev.TabIndex = 17;
            this.Prev.Text = "Назад";
            this.Prev.UseVisualStyleBackColor = true;
            this.Prev.Click += new System.EventHandler(this.Prev_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(39, 224);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "отмена";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // RegForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(283, 309);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Prev);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tx7);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tx6);
            this.Controls.Add(this.tx5);
            this.Controls.Add(this.tx4);
            this.Controls.Add(this.tx3);
            this.Controls.Add(this.tx2);
            this.Controls.Add(this.tx1);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Reg);
            this.Name = "RegForm";
            this.Text = "Регистрация";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Reg;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.TextBox tx1;
        private System.Windows.Forms.TextBox tx2;
        private System.Windows.Forms.TextBox tx3;
        private System.Windows.Forms.TextBox tx4;
        private System.Windows.Forms.TextBox tx5;
        private System.Windows.Forms.TextBox tx6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tx7;
        private System.Windows.Forms.Button Prev;
        private System.Windows.Forms.Button button1;
    }
}